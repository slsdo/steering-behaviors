import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class boids extends PApplet {



/* Steering Behaviors
   http://www.futuredatalab.com/steeringbehaviors/
   
   Compatible with Processing 3.0.1 and ControlP5 2.2.5 */
   
// Global variables
World world;
ControlP5 cp5;

// Setup the Processing Canvas
public void setup() {
  
  world = new World();
  controlUI();
}

// Main draw loop
public void draw() {
  background(255);
  world.run();
}

public void keyPressed() {
  // Display info
  if (key == 'a') {
    info = !info;
  }
  // Boundary mode
  if (key == 's') {
    bounded = !bounded;
    cp5.getController("Bound").setValue((bounded) ? 1 : 0);
    redraw();
  }
  // Debug mode
  if (key == 'd') {
    debug = !debug;
    cp5.getController("Debug").setValue((debug) ? 1 : 0);
    redraw();
  }
  // Reset
  if (key == ' ') {
    world = new World();
    redraw();
  }
}

public void mousePressed() {
  mouseAction(); // Add/Delete one by one
}

public void mouseDragged() {
  mouseAction(); // Add/Delete multiple
}

public void mouseAction() {
  if (keyPressed) {
    if (mouseButton == LEFT) {
      // Add boid
      if (key == 'z' && bNum < 500) {
        Agent boid = new Agent(mouseX, mouseY, 1);
        world.boids.add(boid);
        bNum = world.boids.size();
        cp5.getController("Boid Num").setValue(bNum);
      }
      else if (key == 'x' && pNum < 200) {
        Agent predator = new Agent(mouseX, mouseY, 2);
        world.predators.add(predator);
        pNum = world.predators.size();
        cp5.getController("Predator Num").setValue(pNum);
      }
      else if (key == 'c' && oNum < 50) {
        Obj obj = new Obj(mouseX, mouseY, random(50, 100), round(random(1, 2)));
        world.objs.add(obj);
        oNum = world.objs.size();
        cp5.getController("Object Num").setValue(oNum);
      }
    }
    if (mouseButton == RIGHT) {
      // Remove boid
      if (key == 'z') {
        if (world.boids.size() > 0) {
          world.boids.remove(0);
          bNum = world.boids.size();
          cp5.getController("Boid Num").setValue(bNum);
        }
      }
      // Remove predator
      else if (key == 'x') {
        if (world.predators.size() > 0) {
          world.predators.remove(0);
          pNum = world.predators.size();
          cp5.getController("Predator Num").setValue(pNum);
        }
      }
      // Remove object
      else if (key == 'c') {
        if (world.objs.size() > 0) {
          world.objs.remove(0);
          oNum = world.objs.size();
          cp5.getController("Object Num").setValue(oNum);
        }
      }
    }
  }
}
class Agent {
  float mass;
  float energy;
  PVector pos; // Position
  PVector vel; // Velocity
  PVector acc; // Acceleration
  int type; // Agent type
  float wdelta; // Wander delta
  int action; // Current action
  int prey; // Predator's target
  // Weights
  float wArr;
  float wDep;
  float wPur;
  float wEva;
  float wWan;
  float wAvo;
  float wFlo;
  float wCoh;
  float wSep;
  float wAli;

  Agent(float px, float py, int t) {
    mass = 10.0f;
    energy = 10*ceil(random(5, 10));
    pos = new PVector(px, py);
    vel = new PVector(random(-5, 5), random(-5, 5));
    acc = new PVector();
    type = t;
    wdelta = 0.0f;
    action = 0;
    updateweight();
  }

  public void run(ArrayList boids, ArrayList predators, ArrayList objs) {
    acc.set(0, 0, 0); // Reset accelertion to 0 each cycle
    steer(boids, predators, objs); // Update steering with approprate behavior
    vel.add(acc); // Update velocity
    switch (action) {
      case 1: vel.limit(maxpursue); break; // Limit pursue speed
      case 2: vel.limit(maxevade); break; // Limit evade speed
      default: vel.limit(maxspeed); break; // Limit speed      
    }
    pos.add(vel); // Move agent
    bounding(); // Wrap around the screen or else...
    updateweight(); // Updates weights
    render();
  }

  public void steer(ArrayList boids, ArrayList predators, ArrayList objs) { 
    if (type == 2) predator(boids); // Determine current action
    // Initialize steering forces
    PVector arr = new PVector();
    PVector dep = new PVector();
    PVector pur = new PVector();
    PVector eva = new PVector();
    PVector wan = new PVector();
    PVector flo = new PVector();
    PVector avo = new PVector();
    // Calculate steering forces
    switch (action) {
      // Evading
      case 1: {
        eva = evade(predators);
        avo = avoid(objs); 
        break; 
      }
      // Pursuing
      case 2: {
        pur = pursue(boids);
        avo = avoid(objs);  
        break;
      }
      // Wandering
      default: {
        if (type == 1) {
          wan = wander(); 
          avo = avoid(objs);
          flo = flocking(boids);
          eva = evade(predators);
          break;
        }
        if (type == 2) {
          wan = wander(); 
          avo = avoid(objs);   
          break;
        }
      }      
    }
    // User interaction
    if (mousePressed && keyPressed == false && type == 1) {
      // Left mouse button - Arrival
      if (mouseButton == LEFT) {
        PVector mouse = new PVector(mouseX, mouseY);
        arr = arrival(mouse);
      }
      // Right mouse button - Departure
      else if (mouseButton == RIGHT) {
        PVector mouse = new PVector(mouseX, mouseY);
        dep = departure(mouse);
        dep.mult(maxevade);
      }
    }
    // Apply weights
    arr.mult(wArr);
    dep.mult(wDep);
    pur.mult(wPur);
    eva.mult(wEva);
    wan.mult(wWan);
    avo.mult(wAvo);
    flo.mult(wFlo);
    // Accumulate steering force
    acc.add(arr);
    acc.add(dep);
    acc.add(pur);
    acc.add(eva);
    acc.add(wan);
    acc.add(avo);
    acc.add(flo);
    acc.limit(maxforce); // Limit to maximum steering force
  }
  
  public void predator(ArrayList boids) {
    if (energy > 0) energy -= random(0.5f);
    if (energy < 0) energy = 10*ceil(random(5, 10));
    if (energy < 20 && action == 0) {
      action = 2;
      prey = PApplet.parseInt(random(boids.size() - 1));
    }        
    if (energy > 20 && action == 2) action = 0;
  }

  public PVector seek(PVector target) {
    PVector steer; // The steering vector
    PVector desired = PVector.sub(target, pos); // A vector pointing from current location to the target
    float distance = mag2(desired); // Distance from the target is the magnitude of the vector
    // If the distance is greater than 0, calc steering (otherwise return zero vector)
    if (distance > 0) {     
      desired.normalize(); // Normalize desired
      desired.mult(maxforce);
      steer = PVector.sub(desired, vel); // Steering = Desired minus Velocity
    }
    else {
      steer = new PVector(0, 0);
    }
    return steer;
  }

  public PVector flee(PVector target) {
    PVector steer; // The steering vector
    PVector desired = PVector.sub(target, pos); // A vector pointing from current location to the target
    float distance = mag2(desired); // Distance from the target is the magnitude of the vector
    // If the distance is greater than 0, calc steering (otherwise return zero vector)
    if (distance > 0 && distance < (ARadius*100)*(ARadius*100)) {
      desired.normalize(); // Normalize desired
      desired.mult(maxforce);
      steer = PVector.sub(vel, desired); // Steering = Desired minus Velocity
    }
    else {
      steer = new PVector(0, 0);
    }
    return steer;
  }

  public PVector arrival(PVector target) {
    PVector steer; // The steering vector
    PVector desired = PVector.sub(target, pos); // A vector pointing from current location to the target
    float distance = mag2(desired); // Distance from the target is the magnitude of the vector
    // If the distance is greater than 0, calc steering (otherwise return zero vector)
    if (distance > 0) {
      desired.normalize(); // Normalize desired
      if (distance < ARadius*ARadius) {
        distance = (float) Math.sqrt(distance);
        desired.mult(maxspeed*(distance/ARadius)); // This damping is somewhat arbitrary
      }
      else desired.mult(maxforce);
      steer = PVector.sub(desired, vel); // Steering = Desired minus Velocity
    }
    else {
      steer = new PVector();
    }
    return steer;
  }

  public PVector departure(PVector target) {
    PVector steer; // The steering vector
    PVector desired = PVector.sub(target, pos); // A vector pointing from current location to the target
    float distance = mag2(desired); // Distance from the target is the magnitude of the vector
    // If the distance is greater than 0, calc steering (otherwise return zero vector)
    if (distance > 0 && distance < (ARadius*100)*(ARadius*100)) {
      desired.normalize(); // Normalize desired
      if (distance < ARadius*ARadius) {
        distance = (float) Math.sqrt(distance);
        desired.mult(maxspeed*(ARadius/distance)); // This damping is somewhat arbitrary
      }
      else desired.mult(maxforce);
      steer = PVector.sub(vel, desired); // Steering = Desired minus Velocity
    }
    else {
      steer = new PVector();
    }
    return steer;
  }
  
  public PVector pursue(ArrayList boids) {
    PVector steer = new PVector();
    if (prey < boids.size()) {
      Agent boid = (Agent) boids.get(prey);
      steer = PVector.sub(boid.pos, pos);
      steer.mult(maxpursue);
    }
    return steer;
  }
  
  public PVector evade(ArrayList predators) {
    PVector steer = new PVector();
    for (int i = 0; i < predators.size(); i++) {
      Agent predator = (Agent) predators.get(i);
      float distance = dist2(pos, predator.pos);
      if (distance < ERadius*ERadius) {
        action = 1;
        steer = flee(predator.pos);
        steer.mult(maxevade);
        return steer;
      }
    }
    action = 0;
    return steer;
  }

  public PVector wander() {
    wdelta += random(-NRadius, NRadius); // Determine noise ratio
    // Calculate the new location to steer towards on the wander circle
    PVector center = vel.get(); // Get center of wander circle
    center.mult(60.0f); // Multiply by distance
    center.add(pos); // Make it relative to boid's location
    // Apply offset to get new target    
    PVector offset = new PVector(WRadius*cos(wdelta), WRadius*sin(wdelta));
    PVector target = PVector.add(center, offset); // Determine new target
    // Steer toward new target    
    PVector steer = seek(target); // Steer towards it    
    return steer;
  }
  
  public PVector avoid(ArrayList objs) {
    PVector steer  = new PVector();    

    for (int i = 0; i < objs.size(); i++) {
      Obj obj = (Obj) objs.get(i);
      // Distance between object and avoidance sphere
      float distance = dist2(obj.pos, pos);
      // If distance is less than the sum of the two radius, there is collision
      float bound = obj.mass*0.5f + BRadius + ORadius;
      if (distance < bound*bound) {
        wAvo = 10.0f;
        wWan = 0.1f;
        float collision = (obj.mass + mass)*0.5f;
        if (distance < collision*collision) {
          steer = PVector.sub(pos, obj.pos);
          steer.mult(maxforce*0.1f);
          return steer;
        }
        else {
          float direction = dist2(obj.pos, PVector.add(pos, vel));
          // If is heading toward obstacle
          if (direction < distance) {
            // If steering in the verticle direction
            if (abs(vel.x) <= abs(vel.y)) {   
              steer = new PVector((pos.x - obj.pos.x), vel.y);
              steer.mult(maxforce*((bound*bound)/distance)*0.001f);       
            }
            // If steering in the horizontal direction
            else {
              steer = new PVector(vel.x, (pos.y - obj.pos.y));
              steer.mult(maxforce*((bound*bound)/distance)*0.001f);  
            }
          }
        }
      }
    }
    return steer;
  }

  public PVector flocking(ArrayList boids) {
    // Get steering forces
    PVector steer = new PVector();
    PVector coh = new PVector(); // Perceived center
    PVector sep = new PVector(); // Displacement
    PVector ali = new PVector(); // Perceived velocity
    int count = 0;
    // Agents try to fly towards the centre of mass of neighbouring agents
    // Agents try to keep a small distance away from other objects (including other agents)
    // Agents try to match velocity with near agents
    for (int i = 0; i < boids.size(); i++) {
      Agent boid = (Agent) boids.get(i);
      float distance = dist2(pos, boid.pos);
      // Go through each agents
      if (this != boid && distance < Rn*Rn) {
        coh.add(boid.pos); // Cohesion
        ali.add(boid.vel); // Alignment
        count++;
      }      
      // Separation
      if (this != boid && distance < SDistance*SDistance) {
        PVector diff = PVector.sub(boid.pos, pos); // (agent.position - bJ.position)
        diff.normalize();
        distance = (float) Math.sqrt(distance);
        diff.div(distance); // Weighed by distance
        sep.sub(diff); // c = c - (agent.position - bJ.position)
      }
    }
    if (count > 0) {
      // Cohesion - Step towards the center of mass
      coh.div((float)count); // cJ = pc / (N-1)
      coh.sub(pos); // (pcJ - bJ.position)
      coh.mult(CStep); // (pcJ - bJ.position) / 100
    // Alignment - Find average velocity
      ali.div((float)count); // pvJ = pvJ / N-1
      ali.sub(vel); // (pvJ - bJ.velocity)
      ali.mult(AVelocity); // (pvJ - bJ.velocity) / 8
    }
    // Apply weights
    coh.mult(wCoh);
    sep.mult(wSep);
    ali.mult(wAli);
    // Accumulate forces
    steer.add(coh);
    steer.add(sep);
    steer.add(ali);
    // Add speed
    steer.mult(maxspeed);
    return steer;
  }
  
  // Wrap around or bounded 
  public void bounding() {
    if (bounded) {
      if (pos.x <= BRadius) vel.x = BRadius - pos.x;
      else if (pos.x >= width - BRadius) vel.x = (width - BRadius) - pos.x;
      if (pos.y <= BRadius) vel.y = BRadius - pos.y;
      else if (pos.y >= height - BRadius) vel.y = (height - BRadius) - pos.y;
    }
    else {
      if (pos.x < -mass) pos.x = width + mass;
      if (pos.y < -mass) pos.y = height + mass;
      if (pos.x > width + mass) pos.x = -mass;
      if (pos.y > height + mass) pos.y = -mass;
    }
  }
  
  public void updateweight() {
    wArr = KArrive;
    wDep = KDepart;
    wPur = KPursue;
    wEva = KEvade;
    wWan = KWander;
    wAvo = KAvoid;
    wFlo = KFlock;
    wCoh = KCohesion;
    wSep = KSeparate;
    wAli = KAlignment;
  }
  
  public void render() {   
    if (type == 1) {
      fill(156, 206, 255);
      stroke(16, 16, 222);
      ellipse(pos.x, pos.y, mass, mass);
      PVector dir = vel.get();
      dir.normalize();
      line(pos.x, pos.y, pos.x + dir.x*10, pos.y + dir.y*10);
    }
    else if (type == 2) {
      // Draw a triangle rotated in the direction of velocity        
      float theta = vel.heading2D() + radians(90);
      pushMatrix();
      translate(pos.x, pos.y);
      rotate(theta);
      fill(220, 0, 0);
      noStroke();
      beginShape(TRIANGLES);
      vertex(0, -mass);
      vertex(-3, mass);
      vertex(3, mass);
      endShape();
      popMatrix();
    }
    // Debug mode
    if (debug) {
      // Velocity
      stroke(16, 148, 16);
      line(pos.x, pos.y, pos.x + vel.x*4, pos.y + vel.y*4);
      // Steering
      stroke(255, 0, 0);
      line(pos.x, pos.y, pos.x + acc.x*20, pos.y + acc.y*20);
      // Neighborhood radius
      fill(239, 239, 239, 10);
      stroke(132, 132, 132);
      ellipse(pos.x, pos.y, Rn*2, Rn*2);
      fill(100, 100, 100, 30);
      noStroke();
      ellipse(pos.x, pos.y, BRadius*2, BRadius*2);
      stroke(255, 0, 0);
      noFill();
    }
  }
  
  public float dist2(PVector v1, PVector v2) {
    return ((v1.x - v2.x)*(v1.x - v2.x) + (v1.y - v2.y)*(v1.y - v2.y) + (v1.z - v2.z)*(v1.z - v2.z));
  }
  
  public float mag2(PVector v) {
    return (v.x*v.x + v.y*v.y + v.z*v.z);
  }
}
// World
public int bNum = 40;
public int pNum = 2;
public int oNum = 5;

// Canvas
public boolean info = false; // Display information
public boolean bounded = true; // Bounded within world
public boolean debug = false; // Display viewing fields and more

// Agent
public float Rn = 80.0f; // R neighborhood
public float maxspeed = 5.0f; // Maximum speed
public float maxforce = 3.0f; // Maximum steering force
public float maxpursue = 20.0f; // Maximum steering force
public float maxevade = 10.0f; // Maximum steering force

// Steering
public float ARadius = 100.0f; // Arrival: max distance at which the agent may begin to slow down
public float ERadius = 50.0f; // Evade: radius of evade range
public float WRadius = 40.0f; // Wander: radius of wandering circle
public float NRadius = 0.3f; // Wander: radius of wander noise circle
public float BRadius = 20.0f; // Avoid: radius of agent bounding sphere
public float ORadius = 20.0f; // Avoid: radius of object bounding sphere
public float CStep = 1.0f/100.0f; // Cohesion: move it #% of the way towards the center
public float SDistance = 80.0f; // Separation: small separation distance
public float AVelocity = 1.0f/8.0f; // Alignment: add a small portion to the velocity

// Weights
public float KArrive = 1.0f;
public float KDepart = 1.0f;
public float KPursue = 1.0f;
public float KEvade = 1.0f;
public float KWander = 1.0f;
public float KAvoid = 5.0f;
public float KFlock = 1.0f;
public float KCohesion = 1.0f;
public float KSeparate = 2.0f;
public float KAlignment = 1.0f;

public void controlUI() {
  // Position offsets
  int xoffset = 10;
  int yoffset = 15;
  int canvasoffset = 10;
  int worldoffset = 60;
  int agentoffset = 130;
  int steeroffset = 230;
  int flockoffset = 345;
  int weightoffset = 415;
  
  cp5 = new ControlP5(this);
  // Group menu items
  ControlGroup ui = cp5.addGroup("Settings").setPosition(585, 10).setWidth(215);
  ui.setBackgroundColor(color(0, 200));
  ui.setBackgroundHeight(590);
  ui.mousePressed(); // Menu is hidden by default
  // Increment/decrement stuff in the world  
  Textlabel textWorld = cp5.addTextlabel("World").setText("World").setPosition(xoffset, worldoffset);
  textWorld.setColorValue(color(200));
  Slider sliderBoid = cp5.addSlider("Boid Num").setRange(0, 500).setValue(bNum).setPosition(xoffset, worldoffset + yoffset*1).setSize(100, 10);
  Slider sliderPredator = cp5.addSlider("Predator Num").setRange(0, 100).setValue(pNum).setPosition(xoffset, worldoffset + yoffset*2).setSize(100, 10);
  Slider sliderObject = cp5.addSlider("Object Num").setRange(0, 50).setValue(oNum).setPosition(xoffset, worldoffset + yoffset*3).setSize(100, 10);
  // Canvas settings and more
  Textlabel textCanvas = cp5.addTextlabel("Canvas").setText("Canvas Options").setPosition(xoffset, canvasoffset);
  textCanvas.setColorValue(color(200));
  Toggle toggleInfo = cp5.addToggle("Info").setValue(info).setPosition(xoffset + 0, canvasoffset + yoffset*1).setSize(10, 10);
  Toggle toggleBound = cp5.addToggle("Bound").setValue(bounded).setPosition(xoffset + 45, canvasoffset + yoffset*1).setSize(10, 10);
  Toggle toggleDebug = cp5.addToggle("Debug").setValue(debug).setPosition(xoffset + 90, canvasoffset + yoffset*1).setSize(10, 10);
  Button buttonDefault = cp5.addButton("Default").setValue(0).setPosition(xoffset + 135, canvasoffset + yoffset*1).setSize(45, 10);
  Button buttonReset = cp5.addButton("Reset").setValue(0).setPosition(xoffset + 135, canvasoffset + yoffset*2).setSize(45, 10);
  // Speed variables
  Textlabel textAgent = cp5.addTextlabel("Agent").setText("Agent").setPosition(xoffset, agentoffset);
  textAgent.setColorValue(color(200));
  Slider sliderRn = cp5.addSlider("Neighborhood").setRange(1, 200).setValue(Rn).setPosition(xoffset, agentoffset + yoffset*1).setSize(100, 10);
  Slider sliderMaxSpeed = cp5.addSlider("Max Speed").setRange(1, 10).setValue(maxspeed).setPosition(xoffset, agentoffset + yoffset*2).setSize(100, 10);
  Slider sliderMaxForce = cp5.addSlider("Max Force").setRange(1, 10).setValue(maxforce).setPosition(xoffset, agentoffset + yoffset*3).setSize(100, 10);
  Slider sliderMaxPursue = cp5.addSlider("Pursue Speed").setRange(1, 20).setValue(maxpursue).setPosition(xoffset, agentoffset + yoffset*4).setSize(100, 10);
  Slider sliderMaxEvade = cp5.addSlider("Evade Speed").setRange(1, 20).setValue(maxevade).setPosition(xoffset, agentoffset + yoffset*5).setSize(100, 10);
  // Steering variables
  Textlabel textSteer = cp5.addTextlabel("Steering").setText("Steering").setPosition(xoffset, steeroffset);
  textSteer.setColorValue(color(200));
  Slider sliderARadius = cp5.addSlider("Arrival Departure").setRange(1, 200).setValue(ARadius).setPosition(xoffset, steeroffset + yoffset*1).setSize(100, 10);
  Slider sliderERadius = cp5.addSlider("Evasion").setRange(1, 200).setValue(ERadius).setPosition(xoffset, steeroffset + yoffset*2).setSize(100, 10);
  Slider sliderWRadius = cp5.addSlider("Wandering").setRange(1, 200).setValue(WRadius).setPosition(xoffset, steeroffset + yoffset*3).setSize(100, 10);
  Slider sliderNRadius = cp5.addSlider("Wandering Noise").setRange(0.1f, 1).setValue(NRadius).setPosition(xoffset, steeroffset + yoffset*4).setSize(100, 10);
  Slider sliderBRadius = cp5.addSlider("Agent Avoidance").setRange(1, 200).setValue(BRadius).setPosition(xoffset, steeroffset + yoffset*5).setSize(100, 10);
  Slider sliderORadius = cp5.addSlider("Object Avoidance").setRange(1, 200).setValue(ORadius).setPosition(xoffset, steeroffset + yoffset*6).setSize(100, 10);
  // Flocking variables
  Textlabel textFlock = cp5.addTextlabel("Flocking").setText("Flocking").setPosition(xoffset, flockoffset);
  textFlock.setColorValue(color(200));
  Slider sliderCStep = cp5.addSlider("Cohesion Step").setRange(0.01f, 0.1f).setValue(CStep).setPosition(xoffset, flockoffset + yoffset*1).setSize(100, 10);
  Slider sliderSDistance = cp5.addSlider("Separation Distance").setRange(1, 200).setValue(SDistance).setPosition(xoffset, flockoffset + yoffset*2).setSize(100, 10);
  Slider sliderAVelocity = cp5.addSlider("Alignment Velocity").setRange(0.01f, 0.5f).setValue(AVelocity).setPosition(xoffset, flockoffset + yoffset*3).setSize(100, 10);
  // Weight constants
  Textlabel textWeight = cp5.addTextlabel("Weights").setText("Weights").setPosition(xoffset, weightoffset);
  textWeight.setColorValue(color(200));
  Slider sliderKArrive = cp5.addSlider("Arrive").setRange(1, 10).setValue(KArrive).setPosition(xoffset, weightoffset + yoffset*1).setSize(100, 10);
  Slider sliderKDepart = cp5.addSlider("Depart").setRange(1, 10).setValue(KDepart).setPosition(xoffset, weightoffset + yoffset*2).setSize(100, 10);
  Slider sliderKPursue = cp5.addSlider("Pursue").setRange(1, 10).setValue(KPursue).setPosition(xoffset, weightoffset + yoffset*3).setSize(100, 10);
  Slider sliderKEvade = cp5.addSlider("Evade").setRange(1, 10).setValue(KEvade).setPosition(xoffset, weightoffset + yoffset*4).setSize(100, 10);
  Slider sliderKWander = cp5.addSlider("Wander").setRange(1, 10).setValue(KWander).setPosition(xoffset, weightoffset + yoffset*5).setSize(100, 10);
  Slider sliderKAvoid = cp5.addSlider("Avoid").setRange(1, 10).setValue(KAvoid).setPosition(xoffset, weightoffset + yoffset*6).setSize(100, 10);
  Slider sliderKFlock = cp5.addSlider("Flock").setRange(1, 10).setValue(KFlock).setPosition(xoffset, weightoffset + yoffset*7).setSize(100, 10);
  Slider sliderKCohesion = cp5.addSlider("Cohesion").setRange(1, 10).setValue(KCohesion).setPosition(xoffset, weightoffset + yoffset*8).setSize(100, 10);
  Slider sliderKSeparate = cp5.addSlider("Separate").setRange(1, 10).setValue(KSeparate).setPosition(xoffset, weightoffset + yoffset*9).setSize(100, 10);
  Slider sliderKAlignment = cp5.addSlider("Alignment").setRange(1, 10).setValue(KAlignment).setPosition(xoffset, weightoffset + yoffset*10).setSize(100, 10);
  // Assign ID to all menu items
  sliderBoid.setId(1);
  sliderPredator.setId(2);
  sliderObject.setId(3);
  toggleInfo.setId(4);
  toggleBound.setId(5);
  toggleDebug.setId(6);
  buttonDefault.setId(7);
  buttonReset.setId(8);
  sliderRn.setId(9);
  sliderMaxSpeed.setId(10);
  sliderMaxForce.setId(11);
  sliderMaxPursue.setId(12);
  sliderMaxEvade.setId(13);
  sliderARadius.setId(14);
  sliderERadius.setId(15);
  sliderWRadius.setId(16);
  sliderNRadius.setId(17);
  sliderBRadius.setId(18);
  sliderORadius.setId(19);
  sliderCStep.setId(20);
  sliderSDistance.setId(21);
  sliderAVelocity.setId(22);
  sliderKArrive.setId(23);
  sliderKDepart.setId(24);
  sliderKPursue.setId(25);
  sliderKEvade.setId(26);
  sliderKWander.setId(27);
  sliderKAvoid.setId(28);
  sliderKFlock.setId(29);
  sliderKCohesion.setId(30);
  sliderKSeparate.setId(31);
  sliderKAlignment.setId(32);  
  // Add all menu items to the UI group
  textWorld.setGroup(ui);
  sliderBoid.setGroup(ui);
  sliderPredator.setGroup(ui);
  sliderObject.setGroup(ui);  
  textCanvas.setGroup(ui);
  toggleInfo.setGroup(ui);
  toggleBound.setGroup(ui);
  toggleDebug.setGroup(ui);
  buttonDefault.setGroup(ui);
  buttonReset.setGroup(ui);  
  textAgent.setGroup(ui);
  sliderRn.setGroup(ui);
  sliderMaxSpeed.setGroup(ui);
  sliderMaxForce.setGroup(ui);
  sliderMaxPursue.setGroup(ui);
  sliderMaxEvade.setGroup(ui);  
  textSteer.setGroup(ui);
  sliderARadius.setGroup(ui);
  sliderERadius.setGroup(ui);
  sliderWRadius.setGroup(ui);
  sliderNRadius.setGroup(ui);
  sliderBRadius.setGroup(ui);
  sliderORadius.setGroup(ui);  
  textFlock.setGroup(ui);
  sliderCStep.setGroup(ui);
  sliderSDistance.setGroup(ui);
  sliderAVelocity.setGroup(ui);  
  textWeight.setGroup(ui);
  sliderKArrive.setGroup(ui);
  sliderKDepart.setGroup(ui);
  sliderKPursue.setGroup(ui);
  sliderKEvade.setGroup(ui);
  sliderKWander.setGroup(ui);
  sliderKAvoid.setGroup(ui);
  sliderKFlock.setGroup(ui);
  sliderKCohesion.setGroup(ui);
  sliderKSeparate.setGroup(ui);
  sliderKAlignment.setGroup(ui);
}

// Restore all variables to their default values
public void restoreDefault() {
  updateWorld(40, 2, 5);
  cp5.getController("Boid Num").setValue(bNum);
  cp5.getController("Predator Num").setValue(pNum);
  cp5.getController("Object Num").setValue(oNum);
  info = false;
  bounded = true;
  debug = false;
  cp5.getController("Info").setValue((info) ? 1 : 0);
  cp5.getController("Bound").setValue((bounded) ? 1 : 0);
  cp5.getController("Debug").setValue((debug) ? 1 : 0);
  Rn = 80.0f;
  maxspeed = 5.0f;
  maxforce = 3.0f;
  maxpursue = 20.0f;
  maxevade = 10.0f;
  cp5.getController("Neighborhood").setValue(Rn);
  cp5.getController("Max Speed").setValue(maxspeed);
  cp5.getController("Max Force").setValue(maxforce);
  cp5.getController("Pursue Speed").setValue(maxpursue);
  cp5.getController("Evade Speed").setValue(maxevade);
  ARadius = 100.0f;
  ERadius = 50.0f;
  WRadius = 40.0f;
  NRadius = 0.3f;
  BRadius = 20.0f;
  ORadius = 20.0f;
  CStep = 1.0f/100.0f;
  SDistance = 80.0f;
  AVelocity = 1.0f/8.0f;
  cp5.getController("Arrival Departure").setValue(ARadius);
  cp5.getController("Evasion").setValue(ERadius);
  cp5.getController("Wandering").setValue(WRadius);
  cp5.getController("Wandering Noise").setValue(NRadius);
  cp5.getController("Agent Avoidance").setValue(BRadius);
  cp5.getController("Object Avoidance").setValue(ORadius);
  cp5.getController("Cohesion Step").setValue(CStep);
  cp5.getController("Separation Distance").setValue(SDistance);
  cp5.getController("Alignment Velocity").setValue(AVelocity);
  KArrive = 1.0f;
  KDepart = 1.0f;
  KPursue = 1.0f;
  KEvade = 1.0f;
  KWander = 1.0f;
  KAvoid = 5.0f;
  KFlock = 1.0f;
  KCohesion = 1.0f;
  KSeparate = 2.0f;
  KAlignment = 1.0f;
  cp5.getController("Arrive").setValue(KArrive);
  cp5.getController("Depart").setValue(KDepart);
  cp5.getController("Pursue").setValue(KPursue);
  cp5.getController("Evade").setValue(KEvade);
  cp5.getController("Wander").setValue(KWander);
  cp5.getController("Avoid").setValue(KAvoid);
  cp5.getController("Flock").setValue(KFlock);
  cp5.getController("Cohesion").setValue(KCohesion);
  cp5.getController("Separate").setValue(KSeparate);
  cp5.getController("Alignment").setValue(KAlignment);
}

// Update the number of agents and objects in the world
public void updateWorld(int bn, int pn, int on) {
  if (bn > bNum) {
    bNum = bn;
    while (world.boids.size() < bNum) {
      Agent boid = new Agent(random(width), random(height), 1);
      world.boids.add(boid);
    }
  }
  else if (bn < bNum) {
    bNum = bn;
    while (world.boids.size() >  bNum) {
      world.boids.remove(0);
    }    
  }
  if (pn > pNum) {
    pNum = pn;
    while (world.predators.size() < pNum) {
      Agent predator = new Agent(random(width), random(height), 2);
      world.predators.add(predator);
    }
  }
  else if (pn < pNum) {
    pNum = pn;
    while (world.predators.size() >  pNum) {
      world.predators.remove(0);
    }    
  }
  if (on > oNum) {
    oNum = on;
    while (world.objs.size() < oNum) {
      Obj obj = new Obj(random(1, width), random(1, height), random(50, 100), round(random(1, 2)));
      world.objs.add(obj);
    }
  }
  else if (on < oNum) {
    oNum = on;
    while (world.objs.size() >  oNum) {
      world.objs.remove(0);
    }    
  }
}

// Event handler
public void controlEvent(ControlEvent theEvent) {
  switch(theEvent.getController().getId()) {
    case 1: { updateWorld((int)theEvent.getController().getValue(), pNum, oNum); break; }
    case 2: { updateWorld(bNum, (int)theEvent.getController().getValue(), oNum); break; }
    case 3: { updateWorld(bNum, pNum, (int)theEvent.getController().getValue()); break; }
    case 4: { info = (theEvent.getController().getValue() == 1.0f) ? true : false; break; }
    case 5: { bounded = (theEvent.getController().getValue() == 1.0f) ? true : false; break; }
    case 6: { debug = (theEvent.getController().getValue() == 1.0f) ? true : false; break; }
    case 7: { restoreDefault(); break; }
    case 8: { world = new World(); redraw(); break; }
    case 9: { Rn = theEvent.getController().getValue(); break; }
    case 10: { maxspeed = theEvent.getController().getValue(); break; }
    case 11: { maxforce = theEvent.getController().getValue(); break; }
    case 12: { maxpursue = theEvent.getController().getValue(); break; }
    case 13: { maxevade = theEvent.getController().getValue(); break; }
    case 14: { ARadius = theEvent.getController().getValue(); break; }
    case 15: { ERadius = theEvent.getController().getValue(); break; }
    case 16: { WRadius = theEvent.getController().getValue(); break; }
    case 17: { NRadius = theEvent.getController().getValue(); break; }
    case 18: { BRadius = theEvent.getController().getValue(); break; }
    case 19: { ORadius = theEvent.getController().getValue(); break; }
    case 20: { CStep = theEvent.getController().getValue(); break; }
    case 21: { SDistance = theEvent.getController().getValue(); break; }
    case 22: { AVelocity = theEvent.getController().getValue(); break; }
    case 23: { KArrive = theEvent.getController().getValue(); break; }
    case 24: { KDepart = theEvent.getController().getValue(); break; }
    case 25: { KPursue = theEvent.getController().getValue(); break; }
    case 26: { KEvade = theEvent.getController().getValue(); break; }
    case 27: { KWander = theEvent.getController().getValue(); break; }
    case 28: { KAvoid = theEvent.getController().getValue(); break; }
    case 29: { KFlock = theEvent.getController().getValue(); break; }
    case 30: { KCohesion = theEvent.getController().getValue(); break; }
    case 31: { KSeparate = theEvent.getController().getValue(); break; }
    case 32: { KAlignment = theEvent.getController().getValue(); break; }
  }
}
class Obj {
  PVector pos;
  float mass;
  int type;

  Obj(float px, float py, float m, int t) {
    pos = new PVector(px, py);
    mass = m;
    type = t;
  }
}
class World {
  ArrayList boids;
  ArrayList predators;
  ArrayList objs;

  World() {
    initAgents();
    initobjs();
  }

  public void initAgents() {
    // Add boids
    boids = new ArrayList();
    for (int i = 0; i < bNum; i++) {
      Agent boid = new Agent(random(width), random(height), 1);
      boids.add(boid);
    }
    // Add predator
    predators = new ArrayList();
    for (int i = 0; i < pNum; i++) {
      Agent predator = new Agent(random(width), random(height), 2);
      predators.add(predator);
    }
  }

  public void initobjs() {
    objs = new ArrayList();
    // Add objects
    for (int i = 0; i < oNum; i++) {
      Obj obj = new Obj(random(1, width), random(1, height), random(50, 100), round(random(1, 2)));
      objs.add(obj);
    }
  }

  public void run() {
    update();
    render();
  }

  public void update() {
    // Update agents
    for (int i = 0; i < boids.size(); i++) {
      Agent boid = (Agent) boids.get(i);
      boid.run(boids, predators, objs);
    }
    for (int i = 0; i < predators.size(); i++) {
      Agent predator = (Agent) predators.get(i);
      predator.run(boids, predators, objs);
    }
  }

  public void render() {
    // Render objects
    for (int i = 0; i < objs.size(); i++) {
      Obj obj = (Obj) objs.get(i);

      if (obj.type == 1) {
        fill(200, 180, 160);
        stroke(50, 30, 20);
        ellipse(obj.pos.x, obj.pos.y, obj.mass, obj.mass);
      }
      else if (obj.type == 2) {
        fill(120, 190, 150);
        stroke(80, 70, 40);
        ellipse(obj.pos.x, obj.pos.y, obj.mass, obj.mass);
      }
      // Debug mode
      if (debug) {
        // Neighborhood radius
        fill(100, 100, 100, 30);
        noStroke();
        ellipse(obj.pos.x, obj.pos.y, obj.mass + ORadius*2, obj.mass + ORadius*2);
      }
    }
    // Render info
    if (info) {
      fill(0);
      text("FPS: " + frameRate, 15, 20);
      text("Boids: " + (world.boids.size()), 15, 35);
      text("Predators: " + (world.predators.size()), 15, 50);
      text("Objects: " + (world.objs.size()), 15, 65);
    }
  }
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "boids" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
